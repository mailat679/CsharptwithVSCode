﻿using System;
using CSharpWithVSCode.ClassLib;
using System.Collections.Generic;
namespace CSharpWithVSCode.ConsoleApp
{
    class Program
    {
        private static List<int> lBsort= new List<int>();
	    private static List<int> lBsorted= new List<int>();
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            // lBsort.Add(5);
            // lBsort.Add(3);
            // lBsort.Add(4);
            // lBsort.Add(1);
            // SortArray(lBsort);
            CalculateFact(10);
        }
        public static List<int> SortArray(List<int> lBsort)
	{
		int tmp=0;
		for(int i=1;i<=lBsort.Count;i++)
		{
			for(int j=0;j<lBsort.Count-i;j++)
			{
				//Console.WriteLine(lBsort[j]);
				if(lBsort[j]>lBsort[j+1])
				{
					tmp=lBsort[j];//Console.WriteLine(tmp);
					lBsort[j]=lBsort[j+1];
					lBsort[j+1]=tmp;
					Console.WriteLine(tmp + ""+ lBsort[j] + "" + lBsort[j+1]);
					
				}
			}
		}
		
		return lBsorted;
	}

    public static int CalculateFact(int num)

    {
        int result= num;
        for(int i=1;i<num;i++)
        {
            result= result*i;            
        }
        Console.WriteLine(result);

        return result;
    }
    }
}
