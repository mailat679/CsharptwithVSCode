﻿using System;

namespace CSharpWithVSCode.ClassLib
{
    public class Class1
    {
    }
}
